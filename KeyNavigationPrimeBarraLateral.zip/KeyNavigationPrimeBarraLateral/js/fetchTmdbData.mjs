const tmdbApiEndpoint = "https://api.themoviedb.org/3";
const tmdbAuthorizationToken =
    "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlYmFhMjczMzYwYTk2NzhlNTk1NzQ4MGY2YWRkYTNiNyIsIm5iZiI6MTcxOTc5MDEzNC41NTA3MzYsInN1YiI6IjY2NmI0NzVhODgzNmIxNDM4N2NkMjMxYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.H3MzymLd5I99vNksikrAowiR9SKWSfgxByfVdnXX8Mo";

async function fetchTmdbData(endpoint, maxPage, options = {}) {
    const results = [];
    for (let page = 1; page <= maxPage; page++) {
        const pageX = Math.floor(Math.random() * 50) + 1;
        try {
            const response = await fetch(
                `${tmdbApiEndpoint}/${endpoint}&page=${pageX}`,
                {
                    method: "GET",
                    headers: {
                        accept: "application/json",
                        Authorization: `Bearer ${tmdbAuthorizationToken}`,
                    },
                    ...options,
                }
            );
            if (!response.ok) {
                throw new Error(`TMDB API error: ${response.status}`);
            }
            const jsonData = await response.json();
            results.push(...jsonData.results); // concatenate results
        } catch (err) {
            console.error(err);
            return null;
        }
    }
    return results;
}

