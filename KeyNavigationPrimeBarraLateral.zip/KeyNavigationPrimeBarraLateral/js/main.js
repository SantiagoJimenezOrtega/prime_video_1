// Get current screen
var screen = window.screen;

// Set the desired resolution
var desiredWidth = 1280;
var desiredHeight = 720;

// Verify if the current resolution is different from the desired resolution
if (screen.width !== desiredWidth || screen.height !== desiredHeight) {
  // Set the desired resolution
  screen.width = desiredWidth;
  screen.height = desiredHeight;
}

// check for browser
const isChrome = /Chrome/.test(navigator.userAgent);
if (!isChrome) {
  alert("For the best experience, please use Google Chrome.");
}
