
const app = require('express')();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

app.use(express.static('.'));

io.on('connection', (socket) => {
  console.log('Client connected');

  // handle incoming messages from client
    ws.on('message', (message) => {
        const data = JSON.parse(message);
        console.log('Received message:', data);
    
        if (data.type === 'description') {
          console.log('Received description:', data.data); // <--- Log the description here
          // Process the description data here
        }
      });

  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

server.listen(8080, () => {
  console.log('Server started on port 8080');
});