document.addEventListener("DOMContentLoaded", function () {
  const urlParams = new URLSearchParams(window.location.search);
  const backdropUrl = urlParams.get("backdrop");
  const movieTitle = urlParams.get("title");

  const homeButton = document.querySelector(".Home-Button");

  if (backdropUrl) {
    const backgroundImageContainer = document.createElement("div");
    backgroundImageContainer.className = "background-image-container";
    document.body.appendChild(backgroundImageContainer);

    backgroundImageContainer.style.backgroundImage = `url('${backdropUrl}')`;
    backgroundImageContainer.style.backgroundSize = "60%";
    backgroundImageContainer.style.backgroundPosition = "top right";
    backgroundImageContainer.style.backgroundRepeat = "no-repeat";
    backgroundImageContainer.style.width = "100%";
    backgroundImageContainer.style.height = "100%";
    document.body.style.backgroundColor = "black";

    const movieInfoElement = document.createElement("div");
    movieInfoElement.className = "movie-info";

    const titleElement = document.createElement("h1");
    titleElement.className = "title";
    titleElement.textContent = movieTitle;

    document.title = titleElement.textContent;

    const descriptionElement = document.createElement("p");
    descriptionElement.className = "overview";
    descriptionElement.textContent = urlParams.get("overview");

    movieInfoElement.appendChild(titleElement);
    movieInfoElement.appendChild(descriptionElement);

    document.body.appendChild(movieInfoElement);
  } else {
    console.error("Thumbnail URL is empty or invalid");
  }

  /** */
  // Get the return button element
  const returnButton = document.querySelector(".index-link");
});

document.addEventListener("keydown", function (event) {
  if (event.key === "Backspace" || event.keyCode === 8) {
    window.location.href = "index.html";
  }
});

const icons = document.querySelectorAll(
  ".icon-div > .love-it, .icon-div > .like, .icon-div > .dislike"
);

icons.forEach((icon) => {
  icon.addEventListener("focus", () => {
    icon.classList.add("icon-focused");
  });

  icon.addEventListener("blur", () => {
    icon.classList.remove("icon-focused");
  });
});

/** */
const apiUrlBase =
  "https://api.themoviedb.org/3/discover/movie?api_key=ebaa273360a9678e5957480f6adda3b7&language=en-US&with_genres=28&page=";
const randomPage = Math.floor(Math.random() * 200) + 1; // Genera un número aleatorio entre 1 y 999
const apiUrl = apiUrlBase + randomPage;

fetch(apiUrl)
  .then((response) => response.json())
  .then((data) => {
    const movies = data.results;
    const rowContent = document.querySelector("#topRated .row-content");

    movies.forEach((movie, index) => {
      const movieHtml = `
        <div focusable class="movie-card" tabindex="0">
          <img  src="https://image.tmdb.org/t/p/w185${movie.poster_path}" alt="${movie.title}">
        </div>
      `;

      rowContent.innerHTML += movieHtml;

      const movieCard = document.activeElement;
      const movieTitle = movieCard.getAttribute("data-title");
      const movieOverview = movieCard.getAttribute("data-overview");
      const movieBackdrop = movieCard.getAttribute("data-backdrop-path");

      // Add a limit to the number of movies displayed
      if (index >= 5) return; // Show only 5 movies
    });
  })
  .catch((error) => console.error(error));

console.log("Code is running");

// Get the row content element
const rowContent = document.querySelector(".row-content");

// Get all movie cards
setTimeout(() => {
  const movieCards = document.querySelectorAll(".movie-card");
  console.log(movieCards);

  // Keep track of the currently focused movie card index
  let currentMovieCardIndex = 0;

  // Add event listener for keydown events
  document.addEventListener("keydown", (e) => {
    // Check if the pressed key is the "Arrow Down" key
    if (e.key === "ArrowDown") {
      // Focus on the first movie card
      if (movieCards.length > 0) {
        movieCards[0].focus();
        currentMovieCardIndex = 0;
        // Blur all other elements
        document.querySelectorAll("*").forEach((element) => {
          if (element !== movieCards[0]) {
            element.blur();
          }
        });
      }
    }

    // Check if the pressed key is the "Arrow Right" key
    if (e.key === "ArrowRight") {
      // Check if we're currently focused on a movie card
      if (document.activeElement.classList.contains("movie-card")) {
        // Move focus to the next movie card after a short delay
        setTimeout(() => {
          if (currentMovieCardIndex < movieCards.length - 1) {
            currentMovieCardIndex++;
            movieCards[currentMovieCardIndex].focus();
          }
        }, 10); // Add a 10ms delay
      }
    }

    // Check if the pressed key is the "Arrow Left" key
    if (e.key === "ArrowLeft") {
      // Check if we're currently focused on a movie card
      if (document.activeElement.classList.contains("movie-card")) {
        // Move focus to the previous movie card after a short delay
        setTimeout(() => {
          if (currentMovieCardIndex > 0) {
            currentMovieCardIndex--;
            movieCards[currentMovieCardIndex].focus();
          }
        }, 10); // Add a 10ms delay
      }
    }

    // Check if the pressed key is the "Arrow Up" key
    if (e.key === "ArrowUp") {
      // Check if we're currently focused on a movie card
      if (document.activeElement.classList.contains("movie-card")) {
        // Blur all movie cards
        movieCards.forEach((movieCard) => {
          movieCard.blur();
        });
        // Reset current movie card index
        currentMovieCardIndex = 0;
      }
    }
  });
}, 1000); // wait for 1 second
