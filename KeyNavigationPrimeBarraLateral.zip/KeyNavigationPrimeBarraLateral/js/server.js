/**Websocket file in charge of handling the listening process from the client 
 * side and verifying the connection with the server or possible errors.
 */

const express = require('express');
const app = express();

app.use(express.static('public')); // serve static files from public folder

const server = app.listen(3000, () => {
    console.log('Server listening on port 3000');
});

const WebSocket = require('ws');
const wss = new WebSocket.Server({ server: server });

wss.on('connection', (ws) => {
    console.log('Client connected');
    // handle incoming messages from client
    ws.on('message', (message) => {
        const data = JSON.parse(message);
        console.log('Received message:', data);

        if (data.type === 'description') {
            console.log('Received description:', data.data); // <--- Log the description here
            // Process the description data here
        }
    });

    // handle errors
    ws.on('error', (error) => {
        console.log('Error occurred');
        console.log(error);
    });

    // handle client disconnections
    ws.on('close', () => {
        console.log('Client disconnected');
    });
});
// server.js
